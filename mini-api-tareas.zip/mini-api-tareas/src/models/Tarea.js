
const mongoose = require('mongoose');

const tareaSchema = new mongoose.Schema({
    titulo: {
        type: String,
        required: [true, 'El titulo es obligatorio'],
        trim: true
    },

    descripcion: {
        type: String,
        default: '',
        trim: true
    },

    completado: {
        type: Boolean,
        default: false
    },

    fechaCreacion: {
        type: Date,
        default: Date.now
    }
});

// Crear el modelo
const Tarea = mongoose.model('Tarea', tareaSchema);

module.exports = Tarea;
