const express = require('express');
const router = express.Router();

const Tarea = require('../models/Tarea');

router.post('/',async(req,res)=>{
    try{
        const {titulo,descripcion} = req.body;

        const nuevaTarea = new Tarea({
            titulo,
            descripcion
        });

        const tareaGuardada = await nuevaTarea.save();

        res.status(201).json({
            mensaje:'Tarea creada correctamente',
            tarea:tareaGuardada
        });

    }catch (error){
        res.status(400).json({
            mensaje:'Error al crear la tarea',
            error:error.message
        });
    }

});

router.get('/', async(req,res)=>{
    try{
        const tareas = await Tarea.find();

        res.status(200).json(tareas);

    }catch(error){
        res.status(500).json({
            mensaje:'Error al obtener las tareas',
            error:error.message
        });
    }
});

router.get('/:id', async(req,res)=>{
    try{
        const tarea = await Tarea.findById(req.params.id);

        if(!tarea){
            return res.status(404).json({
                mensaje:'Tarea no encontrada'
            });
        }

        res.status(200).json(tarea);

    }catch(error){
        res.status(400).json({
            mensaje:'Error al buscar la tarea',
            error:error.message
        });
    }
});


router.put('/:id', async(req,res)=>{
    try{
        const {titulo,descripcion,completado} = req.body;

        const tareaActualizada = await Tarea.findByIdAndUpdate(
            req.params.id,
            {
                titulo,
                descripcion,
                completado
            },
            {
                new:true,
                runValidators:true
            }
        );

        if(!tareaActualizada){
            return res.status(404).json({
                mensaje:'Tarea no encontrada'
            });
        }

        res.status(200).json({
            mensaje:'Tarea actualizada correctamente',
            tarea:tareaActualizada
        });

    }catch(error){
        res.status(400).json({
            mensaje:'Error al actualizar la tarea',
            error:error.message
        });
    }
});

router.delete('/:id', async(req,res)=>{
    try{
        const tareaEliminada = await Tarea.findByIdAndDelete(req.params.id);

        if(!tareaEliminada){
            return res.status(404).json({
                mensaje:'Tarea no encontrada'
            });
        }

        res.status(200).json({
            mensaje:'Tarea eliminada correctamente',
            tarea:tareaEliminada
        });

    }catch(error){
        res.status(400).json({
            mensaje:'Error al eliminar la tarea',
            error:error.message
        });
    }
});


router.get('/', async(req,res)=>{
    try{
        const tareas = await Tarea.find();

        res.status(200).json(tareas);

    }catch(error){
        res.status(500).json({
            mensaje:'Error al obtener las tareas',
            error:error.message
        });
    }
});


module.exports = router;