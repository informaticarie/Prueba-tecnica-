
require('dotenv').config();
const autenticarToken = require('./middlewares/auth');

const express = require('express');
const cors = require('cors');

const conectarDB = require('./config/database');
const tareasRoutes = require('./routes/tareas.routes');

const app = express();

// Middlewares
app.use(cors());
app.use(express.json());


// Ruta principal
app.get('/', (req, res) => {
    res.json({
        mensaje: 'Bienvenido a la Mini API de Tareas'
    });
});

//rutas de tareas
app.use('/api/tareas',autenticarToken,tareasRoutes);

// Iniciar servidor
const iniciarServidor = async () => {
    await conectarDB();

    const PORT = process.env.PORT || 3000;

    app.listen(PORT, () => {
        console.log(`Servidor ejecutándose en http://localhost:${PORT}`);
    });
};

iniciarServidor();
