
const autenticarToken = (req, res, next) => {

    const token = req.headers['authorization'];

    const tokenValido = '295339';

    if (!token) {
        return res.status(401).json({
            mensaje: 'No se proporcionó un token de autenticación'
        });
    }

    if (token !== tokenValido) {
        return res.status(403).json({
            mensaje: 'Token inválido'
        });
    }

    next();
};

module.exports = autenticarToken;
