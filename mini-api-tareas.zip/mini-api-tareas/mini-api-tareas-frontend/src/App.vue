<script setup>
import { ref, computed, onMounted } from "vue";
import { useTareasStore } from "./stores/tareas";
import Swal from "sweetalert2";

import useVuelidate from "@vuelidate/core";
import { required, minLength } from "@vuelidate/validators";

const store = useTareasStore();

const formulario = ref({
  titulo: "",
  descripcion: "",
});

const tareaEditando = ref(null);

const reglas = computed(() => ({
  titulo: {
    required,
    minLength: minLength(3),
  },
  descripcion: {
    required,
    minLength: minLength(5),
  },
}));

const v$ = useVuelidate(reglas, formulario);

const completadas = computed(
  () => store.tareas.filter((t) => t.completado).length,
);

const pendientes = computed(
  () => store.tareas.filter((t) => !t.completado).length,
);

onMounted(async () => {
  try {
    await store.obtenerTareas();
  } catch (error) {
    Swal.fire(
      "Error",
      store.error || "No se pudieron cargar las tareas",
      "error",
    );
  }
});

const guardarTarea = async () => {
  const valido = await v$.value.$validate();

  if (!valido) {
    return;
  }

  try {
    if (tareaEditando.value) {
      await store.actualizarTarea(tareaEditando.value, { ...formulario.value });

      Swal.fire(
        "¡Actualizada!",
        "La tarea se actualizó correctamente",
        "success",
      );
    } else {
      await store.crearTarea({
        ...formulario.value,
      });

      Swal.fire("¡Creada!", "La tarea se registró correctamente", "success");
    }

    limpiarFormulario();
  } catch (error) {
    Swal.fire(
      "Error",
      error.response?.data?.mensaje || "No se pudo guardar la tarea",
      "error",
    );
  }
};

const editarTarea = (tarea) => {
  tareaEditando.value = tarea._id;

  formulario.value = {
    titulo: tarea.titulo,
    descripcion: tarea.descripcion,
  };

  v$.value.$reset();

  window.scrollTo({ top: 0, behavior: "smooth" });
};

const eliminarTarea = async (id) => {
  const resultado = await Swal.fire({
    title: "¿Eliminar tarea?",
    text: "Esta acción no se puede deshacer",
    icon: "warning",
    showCancelButton: true,
    confirmButtonText: "Sí, eliminar",
    cancelButtonText: "Cancelar",
    confirmButtonColor: "#dc3545",
  });

  if (!resultado.isConfirmed) return;

  try {
    await store.eliminarTarea(id);

    Swal.fire("Eliminada", "La tarea fue eliminada correctamente", "success");
  } catch (error) {
    Swal.fire("Error", "No se pudo eliminar la tarea", "error");
  }
};

const cambiarEstado = async (tarea) => {
  try {
    await store.actualizarTarea(tarea._id, {
      titulo: tarea.titulo,
      descripcion: tarea.descripcion,
      completado: !tarea.completado,
    });
  } catch (error) {
    Swal.fire("Error", "No se pudo actualizar el estado", "error");
  }
};

const limpiarFormulario = () => {
  formulario.value = {
    titulo: "",
    descripcion: "",
  };

  tareaEditando.value = null;
  v$.value.$reset();
};
</script>

<template>
  <div class="container py-5">
    <header class="text-center mb-5">
      <h1 class="fw-bold text-primary">Mi lista de tareas</h1>
      <p class="text-muted">Administra tus actividades fácilmente</p>
    </header>

    <!-- Resumen -->
    <div class="row mb-4 text-center">
      <div class="col-md-4 mb-3">
        <div class="card shadow-sm p-3">
          <h3>{{ store.tareas.length }}</h3>
          <span>Total de tareas</span>
        </div>
      </div>

      <div class="col-md-4 mb-3">
        <div class="card shadow-sm p-3">
          <h3 class="text-warning">{{ pendientes }}</h3>
          <span>Pendientes</span>
        </div>
      </div>

      <div class="col-md-4 mb-3">
        <div class="card shadow-sm p-3">
          <h3 class="text-success">{{ completadas }}</h3>
          <span>Completadas</span>
        </div>
      </div>
    </div>

    <!-- Formulario -->
    <div class="card shadow-sm mb-5">
      <div class="card-header bg-primary text-white">
        {{ tareaEditando ? "Editar tarea" : "Nueva tarea" }}
      </div>

      <div class="card-body">
        <form @submit.prevent="guardarTarea">
          <div class="mb-3">
            <label class="form-label">Título</label>

            <input
              v-model="formulario.titulo"
              type="text"
              class="form-control"
              placeholder="Escribe el título"
            />

            <small v-if="v$.titulo.$error" class="text-danger">
              El título es obligatorio y debe tener al menos 3 caracteres.
            </small>
          </div>

          <div class="mb-3">
            <label class="form-label">Descripción</label>

            <textarea
              v-model="formulario.descripcion"
              class="form-control"
              rows="3"
              placeholder="Describe tu tarea"
            ></textarea>

            <small v-if="v$.descripcion.$error" class="text-danger">
              La descripción es obligatoria y debe tener al menos 5 caracteres.
            </small>
          </div>

          <button type="submit" class="btn btn-primary me-2">
            {{ tareaEditando ? "Guardar cambios" : "Crear tarea" }}
          </button>

          <button
            v-if="tareaEditando"
            type="button"
            class="btn btn-secondary"
            @click="limpiarFormulario"
          >
            Cancelar
          </button>
        </form>
      </div>
    </div>

    <!-- Listado -->
    <h3 class="mb-3">Mis tareas</h3>

    <div v-if="store.cargando" class="text-center py-4">Cargando tareas...</div>

    <div v-else-if="store.tareas.length === 0" class="alert alert-info">
      No tienes tareas registradas.
    </div>

    <div v-else class="row">
      <div v-for="tarea in store.tareas" :key="tarea._id" class="col-md-6 mb-3">
        <div class="card shadow-sm h-100">
          <div class="card-body">
            <div class="d-flex justify-content-between">
              <h5
                :class="{
                  'text-decoration-line-through text-muted': tarea.completado,
                }"
              >
                {{ tarea.titulo }}
              </h5>

              <span
                class="badge"
                :class="
                  tarea.completado ? 'bg-success' : 'bg-warning text-dark'
                "
              >
                {{ tarea.completado ? "Completada" : "Pendiente" }}
              </span>
            </div>

            <p class="text-muted">
              {{ tarea.descripcion }}
            </p>

            <div class="d-flex flex-wrap gap-2">
              <button
                class="btn btn-sm btn-success"
                @click="cambiarEstado(tarea)"
              >
                {{ tarea.completado ? "Reabrir" : "Completar" }}
              </button>

              <button
                class="btn btn-sm btn-primary"
                @click="editarTarea(tarea)"
              >
                Editar
              </button>

              <button
                class="btn btn-sm btn-danger"
                @click="eliminarTarea(tarea._id)"
              >
                Eliminar
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style>
body {
  background-color: #f5f7fb;
}

.card {
  border: none;
  border-radius: 12px;
}

h1 {
  letter-spacing: -1px;
}
</style>
