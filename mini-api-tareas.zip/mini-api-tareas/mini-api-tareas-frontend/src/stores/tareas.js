
import { defineStore } from 'pinia';
import api from '../services/api';

export const useTareasStore = defineStore('tareas', {
    state: () => ({
        tareas: [],
        cargando: false,
        error: null
    }),

    actions: {
        async obtenerTareas() {
            this.cargando = true;
            this.error = null;

            try {
                const respuesta = await api.get('/tareas');
                this.tareas = respuesta.data;
            } catch (error) {
                this.error = error.response?.data?.mensaje || 'Error al obtener tareas';
                throw error;
            } finally {
                this.cargando = false;
            }
        },

        async crearTarea(datos) {
            try {
                const respuesta = await api.post('/tareas', datos);
                this.tareas.push(respuesta.data.tarea);
                return respuesta.data.tarea;
            } catch (error) {
                throw error;
            }
        },

        async actualizarTarea(id, datos) {
            try {
                const respuesta = await api.put(`/tareas/${id}`, datos);

                const indice = this.tareas.findIndex(
                    tarea => tarea._id === id
                );

                if (indice !== -1) {
                    this.tareas[indice] = respuesta.data.tarea;
                }

                return respuesta.data.tarea;
            } catch (error) {
                throw error;
            }
        },

        async eliminarTarea(id) {
            try {
                await api.delete(`/tareas/${id}`);

                this.tareas = this.tareas.filter(
                    tarea => tarea._id !== id
                );
            } catch (error) {
                throw error;
            }
        }
    }
});
